###
### ps.py
###
### Add your answers and code to this file.
###

### Name:

from adventure import *  # this brings everything in adventure.py into our namespace
from ri import *

### Importing * like this is bad practice since it pollutes the namespace,
### but avoids the need to use module names.

### Question 1:

"""
You can use triple-quotes to start and end a multi-line comment in Python.
Use this to enter your answers to questions other than code for the
adventure game, such as your Python expressions for Question 1.
"""

### Question 2:

### Question 3:

### Question 4:
               
### Question 5:

class Prefect (Person):
    def __init__(self, name, jail):   ### keep this!
        Person.__init__(self, name)
        self.set_restlessness(0.5)
        self.__jail = jail

    # Question 6: define the book method
        
    # Question 7: define the tick method
### Question 8:

"""
Describe your extension and answer the questions a-e about it.
"""

# code for your extension
