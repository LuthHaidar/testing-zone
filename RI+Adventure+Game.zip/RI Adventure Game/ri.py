#
# ri.py
#

from adventure import * 
import ps
   
def setup_ri():
    ri = World("Raffles Institution")

    # Add some of our favorite places in RI
    ri.add_place(Place('Albert Hong Hall'))   
    ri.add_place(Place('Artspace')) 
    ri.add_place(Place('Tennis Court'))   
    ri.add_place(Place('S. Rajaratnam Block'))      
    ri.add_place(Place('The Boarding School')) 
    ri.add_place(Place('Hong Leong Swimming Complex')) 
    ri.add_place(Place('Raffles Square')) 
    ri.add_place(Place('Canteen'))    
    ri.add_place(Place('Marshall Block')) 
    ri.add_place(Place('Yusof Ishak Block'))    
    ri.add_place(Place('Sheares Block'))
    ri.add_place(Place('Auditorium'))   
    ri.add_place(Place('Bus Stop Along Bishan Road'))   
    ri.add_place(Place('Astroturf')) 
    ri.add_place(Place('Hullet Memorial Library'))
    ri.add_place(Place('Principal Office'))

    
    ri.connect_both_ways('Albert Hong Hall', 'north', 'Auditorium')
    ri.connect_both_ways('Auditorium', 'north', 'Canteen')
    ri.connect_both_ways('Raffles Square', 'north', 'Yusof Ishak Block')
    ri.connect_both_ways('Raffles Square', 'west', 'Hullet Memorial Library')
    ri.connect_both_ways('Yusof Ishak Block', 'north', 'Marshall Block')
    ri.connect_both_ways('Tennis Court', 'west', 'Albert Hong Hall')
    ri.connect_both_ways('Artspace', 'west', 'Tennis Court')
    ri.connect_both_ways('Artspace', 'north', 'Hullet Memorial Library')
    ri.connect_both_ways('Hullet Memorial Library', 'north', 'Sheares Block')
    ri.connect_both_ways('Sheares Block', 'east', 'S. Rajaratnam Block')
    ri.connect_both_ways('Artspace', 'east', 'Hong Leong Swimming Complex')
    ri.connect_both_ways('The Boarding School', 'north', 'S. Rajaratnam Block')
    ri.connect_one_way('Bus Stop Along Bishan Road', 'enter', 'Yusof Ishak Block') # you can check in, but you can never leave
    return ri    

def play_game_as_johan():
    ri = setup_ri()

    # this only works after you have defined the Student and Prefect classes
    johan = ps.Student('Johan')
    ben = ps.Student('Ben Tan')
    ben.set_restlessness(0.333)
    warren = ps.Prefect('Warren K', ri.get_place('Principal Office'))
    ri.install_thing(johan, 'Raffles Square')    
    ri.install_thing(ben, 'Canteen')
    ri.install_thing(warren, 'Raffles Square')
    ri.play_interactively(johan)                            

def play_game_as_warren():
    ri = setup_ri()

    # this only works after you have defined the Student and PoliceOfficer classes
    johan = ps.Student('Johan M')
    johan.set_restlessness(0.5)
    ben = ps.Student('Ben Tan')
    ben.set_restlessness(0.333)
    warren = ps.Prefect('Warren K', ri.get_place('Principal Office'))
    warren.set_restlessness(0)
    ri.install_thing(johan, 'Raffles Square')    
    ri.install_thing(ben, 'Yusof Ishak Block')
    ri.install_thing(warren, 'Raffles Square')
    ri.play_interactively(warren)          
    
